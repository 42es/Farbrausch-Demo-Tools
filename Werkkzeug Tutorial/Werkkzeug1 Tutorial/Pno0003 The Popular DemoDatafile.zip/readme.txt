
the.popular.demo data file

(c) copyright 2004 by .theprodukkt

www.theprodukkt.com

released 15-jun-2004


this is a data-file for .werkkzeug1 containing
fr-025: the.popular.demo. we provide it as an 
example for the .werkkzeug1.


the.popular.demo was originally created by

- thomas "fiver2" mahlke
- dierk "chaos" ohlerich
- sebastian "wayfinder" grillmayer
- sarah hill
- christoph "giZMo" muetze
- mike may
- andr� "tiberius" adam
- borys "phaser" las-opolski
- jeff oxborrow
- ronny

the demo requires a pc with 

- windows 98 or better 
- directx 9.0 or better
- a GeForce2 class 3d graphics card or better
- a 500Mhz pentium-class cpu or better
- 256MB ram

disclaimer:

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
.theprodukkt GmbH OR ITS CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

