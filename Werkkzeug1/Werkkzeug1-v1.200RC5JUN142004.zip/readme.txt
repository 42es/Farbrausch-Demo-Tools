
.werkkzeug1 v1.200

(c) copyright 2004 by .theprodukkt

www.theprodukkt.com

released 15-jun-2004


the .werkkzeug1 is a tool for creating non-interactive
realtime demonstrations. the resulting files can be as
small as 64 kilobytes, including the player software.


developed by

- dierk "chaos" ohlerich
- thomas "fiver2" mahlke
- tammo "kb" hinrichs
- dirk "doj" jagdmann
- fabian "ryg" giesen
- bastian "tron" z�hlke

this program requires a pc with 

- windows 98 or better 
- directx 9.0 or better
- a 3d graphics card 

disclaimer:

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
.theprodukkt GmbH OR ITS CONTRIBUTORS BE LIABLE FOR ANY 
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

